# README
TODO

cabal install matrix
cabal install vector

in ghci
:set -package vector’ to expose it
